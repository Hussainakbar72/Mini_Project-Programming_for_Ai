from flask import Flask, render_template, Response, request, send_file
from camera import generate_frames, start_camera, stop_camera, set_class_section
import csv, os
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt

app = Flask(__name__)


@app.route('/')
def home():
    return render_template("index.html")


@app.route('/start')
def start():
    cls = request.args.get("class")
    sec = request.args.get("section")

    set_class_section(cls, sec)
    start_camera()

    return "Camera Started"


@app.route('/stop')
def stop():
    stop_camera()
    return "Camera Stopped"


@app.route('/video')
def video():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')


# ================= DASHBOARD =================
@app.route('/dashboard')
def dashboard():

    file = "attendance.csv"
    data = []

    if os.path.exists(file):
        with open(file, "r", newline="") as f:
            reader = csv.reader(f)
            data = list(reader)

            if len(data) > 0:
                data = data[1:]

    search = request.args.get("search")
    selected_class = request.args.get("class")

    filtered = []

    for row in data:
        if len(row) != 5:
            continue

        name, cls, sec, date, time = row

        if selected_class and selected_class != "All":
            if cls != selected_class:
                continue

        if search:
            if search.lower() not in name.lower():
                continue

        filtered.append(row)

    # TODAY
    today = str(datetime.now().date())
    today_data = [r for r in filtered if r[3] == today]

    # TOTAL PRESENT
    total_present = len(filtered)

    # MONTHLY ATTENDANCE %
    month = str(datetime.now().month)

    month_data = [r for r in filtered if r[3].split("-")[1] == month]

    student_count = {}
    for r in month_data:
        name = r[0]
        student_count[name] = student_count.get(name, 0) + 1

    total_days = len(set([r[3] for r in month_data])) or 1

    attendance_percentage = {
        name: round((count / total_days) * 100, 2)
        for name, count in student_count.items()
    }

    return render_template(
        "dashboard.html",
        data=filtered,
        today_data=today_data,
        total_present=total_present,
        attendance_percentage=attendance_percentage
    )


# ================= DOWNLOAD CSV =================
@app.route('/download')
def download():
    return send_file("attendance.csv", as_attachment=True)


# ================= GRAPH =================
@app.route('/graph')
def graph():

    df = pd.read_csv("attendance.csv")

    counts = df.groupby("Date").size()

    plt.figure()
    counts.plot(kind='bar')
    plt.title("Attendance Stats")

    path = "static/graph.png"
    plt.savefig(path)

    return render_template("graph.html", img=path)


if __name__ == "__main__":
    app.run(debug=True)