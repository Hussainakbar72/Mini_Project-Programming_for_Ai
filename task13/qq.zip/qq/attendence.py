import cv2
import pickle
import csv
import os
from datetime import datetime

# ================= LOAD MODEL =================
model = cv2.face.LBPHFaceRecognizer_create()
model.read("trainer.yml")

# ================= LOAD LABELS =================
with open("labels_map.pkl", "rb") as f:
    label_dict = pickle.load(f)

reverse_dict = {v: k for k, v in label_dict.items()}

# ================= FACE DETECTOR =================
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

# ================= CAMERA =================
video = cv2.VideoCapture(0)

# ================= ATTENDANCE FILE =================

filename = "attendance.csv"
date = datetime.now().strftime("%Y-%m-%d")
filename = f"attendance_{date}.csv"

marked = set()

while True:
    ret, frame = video.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        face = gray[y:y+h, x:x+w]
        face = cv2.resize(face, (100, 100))

        label, confidence = model.predict(face)
        name = reverse_dict[label]

        # show name
        cv2.putText(frame, name, (x, y-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

        # ================= ATTENDANCE =================
        if name not in marked:
            marked.add(name)

            with open(filename, "a", newline="") as f:
                writer = csv.writer(f)

                if os.stat(filename).st_size == 0:
                    writer.writerow(["Name", "Time"])

                writer.writerow([name, datetime.now().strftime("%H:%M:%S")])

    cv2.imshow("Attendance System", frame)

    if cv2.waitKey(1) == ord('q'):
        break

video.release()
cv2.destroyAllWindows()