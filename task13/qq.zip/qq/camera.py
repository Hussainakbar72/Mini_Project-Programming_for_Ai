import cv2
import pickle
import csv
import os
from datetime import datetime

model = cv2.face.LBPHFaceRecognizer_create()
model.read("trainer.yml")

with open("labels_map.pkl", "rb") as f:
    label_dict = pickle.load(f)

reverse = {v: k for k, v in label_dict.items()}

face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

video = None
running = False
marked = set()

current_class = ""
current_section = ""

filename = "attendance.csv"


def set_class_section(cls, sec):
    global current_class, current_section
    current_class = cls
    current_section = sec


def start_camera():
    global video, running

    if video is None:
        video = cv2.VideoCapture(0)

    running = True


def stop_camera():
    global video, running

    running = False

    if video:
        video.release()
        video = None


def generate_frames():
    global video, running, marked

    today = str(datetime.now().date())

    while True:

        if not running or video is None:
            continue

        success, frame = video.read()
        if not success:
            continue

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:

            face = gray[y:y+h, x:x+w]

            try:
                face = cv2.resize(face, (100, 100))
                label, confidence = model.predict(face)

                if confidence < 80:
                    name = reverse.get(label, "Unknown")
                else:
                    name = "Unknown"

            except:
                name = "Unknown"

            cv2.putText(frame, name, (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)

            cv2.rectangle(frame, (x,y), (x+w,y+h), (0,255,0), 2)

            # ================= ATTENDANCE =================
            if name != "Unknown":

                key = name + today

                if key not in marked:
                    marked.add(key)

                    file_exists = os.path.exists(filename)

                    with open(filename, "a", newline="") as f:
                        writer = csv.writer(f)

                        if not file_exists or os.path.getsize(filename) == 0:
                            writer.writerow(["Name","Class","Section","Date","Time"])

                        writer.writerow([
                            name,
                            current_class,
                            current_section,
                            today,
                            datetime.now().strftime("%H:%M:%S")
                        ])

                    running = False

        _, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')