import cv2
import pickle
import os

face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

name = input("Enter your name: ")

video = cv2.VideoCapture(0)

faces = []
labels = []
count = 0

print("📸 Collecting faces... Press Q to stop")

while True:

    ret, frame = video.read()
    if not ret:
        continue

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces_detected = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces_detected:

        face = gray[y:y+h, x:x+w]
        face = cv2.resize(face, (100, 100))

        # ✅ FIX: stable sampling
        if count % 3 == 0:

            faces.append(face)
            labels.append(name)
            count += 1

        cv2.rectangle(frame, (x,y), (x+w,y+h), (0,255,0), 2)

    cv2.imshow("Collect Faces", frame)

    if cv2.waitKey(1) == ord('q') or count >= 100:
        break

video.release()
cv2.destroyAllWindows()

# ================= SAFE SAVE =================
def load(file):
    if os.path.exists(file):
        with open(file, "rb") as f:
            return pickle.load(f)
    return []

old_faces = load("faces.pkl")
old_labels = load("labels.pkl")

faces = old_faces + faces
labels = old_labels + labels

with open("faces.pkl", "wb") as f:
    pickle.dump(faces, f)

with open("labels.pkl", "wb") as f:
    pickle.dump(labels, f)

print("✅ Data Saved Successfully!")
print("Faces:", len(faces))
print("Labels:", len(labels))