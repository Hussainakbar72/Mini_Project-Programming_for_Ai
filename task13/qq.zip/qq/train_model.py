import cv2
import pickle
import numpy as np
import os

def load(file):
    if os.path.exists(file):
        with open(file, "rb") as f:
            return pickle.load(f)
    return []

faces = load("faces.pkl")
labels = load("labels.pkl")

# 🚨 SAFETY CHECK
if len(faces) == 0 or len(labels) == 0:
    print("❌ Dataset empty! Run data_collection.py first")
    exit()

print("Faces:", len(faces))
print("Labels:", len(labels))

X = np.array(faces, dtype=np.uint8)
X = X.reshape(len(X), 100, 100)

unique_names = sorted(list(set(labels)))
label_dict = {name: i for i, name in enumerate(unique_names)}

y = np.array([label_dict[name] for name in labels])

model = cv2.face.LBPHFaceRecognizer_create()
model.train(X, y)

model.save("trainer.yml")

with open("labels_map.pkl", "wb") as f:
    pickle.dump(label_dict, f)

print("✅ Model Training Complete!")